// module.exports = {
//     HOST: "localhost",
//     USER: "u1437717_admin",
//     PASSWORD: "7vy}lZN$x0@1",
//     DB: "u1437717_ceban_api"
// };

module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "ceban-api"
};